from scrapy.spiders import CrawlSpider, Rule
from ..items import *
from scrapy.linkextractors import LinkExtractor
from scrapy.utils.project import get_project_settings


class Dd11eeSpider(CrawlSpider):
    name = "dd11ee"
    allowed_domains = ['dd']
    start_urls = ['dd']
    rules = (
        Rule(LinkExtractor(allow=('dd1')), callback='dd2',
        follow=False
        ),
    )

    def dd2(self, response):

        item = Dd2Item()
        item['dd6'] = self.get_dd6(response)
        yield item

    def get_dd6(self, response):
        dd6 = response.xpath('dd5').extract()
        return dd6[0] if dd6 else ''

