import sys

from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings
from dd11ee.spiders.dd11ee import Dd11eeSpider


process = CrawlerProcess(get_project_settings())
process.crawl(Dd11eeSpider)
process.start()
