
# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class Xx2Item(scrapy.Item):
    xx4 = scrapy.Field()
    zz6 = scrapy.Field()
